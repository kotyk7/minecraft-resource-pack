przerobione przez @kotyk7 (github) na potrzeby własne
oryginał do pobrania na txtgrafa.pl
